#!/bin/bash
set -euo pipefail
podman build -t cityapp:1.0 .
